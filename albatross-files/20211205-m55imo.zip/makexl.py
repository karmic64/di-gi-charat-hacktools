#yes ok

import sys
import os
import openpyxl as opx
from openpyxl.styles import Border, Side

def parsetxt(txtfile):
    #parse through text file looking for ShowTextBox lines.
    #when you find one, create a new table entry with the following:
    #   replaced text(the whoel !!! 3E56E0 0 thing)
    #   commented out text above the line
    #return this table
    
    data = []
    lines = []
    
    for line in txtfile:
        lines.append(line)
    
    for linenum, line in enumerate(lines):    
        if line[0:11] == "ShowTextBox":
            dummytext = line[13:-2]
            replacedtext = ""
            
            for i in range(linenum-1, 0, -1):
                if lines[i][0] == "#":
                    replacedtext = "".join([lines[i][:], replacedtext]) #this is so dumb
                else:
                    break
                    
            data.append([dummytext, replacedtext[:-1]]) #strip final \n
            
        elif line[0:13] == "ShowSelMenu09": #dumb way of doing it. dont care enough to fix rn. maybe if theres another text method
            dummytext = line[18:-2]
            replacedtext = ""
            
            for i in range(linenum-1, 0, -1):
                if lines[i][0] == "#":
                    replacedtext = "".join([lines[i][:], replacedtext]) #this is so dumb
                else:
                    break
                    
            data.append([dummytext, replacedtext[:-1]]) #strip final \n
        
        elif line[0:9] == "Subscript":
            data.append("NEWSUBSCRIPT")
        
    return data

  
  
def createxlsx(filetitle, data):
    #use incoming data from parsetxt to create a new excel worksheet.
    #format: 
    #header -> data:
    #dummy text, replaced japanese text, empty space for future translation, unchecked comment column
    wb = opx.Workbook()
    ws = wb.active
    
    border = Border(bottom=Side(border_style="thin",color="000000"))
    
    #header:
    ws.append(['Dummy Text','JP Text',"translation","comments"])
    for num, i in enumerate(data):
        if i == "NEWSUBSCRIPT":
            for cell in ws[num+1]:
                cell.border = border
        else:
            ws.append(i)
            #print(i[1].count("#"))
            ws.row_dimensions[num+1].height = 15*i[1].count("#")
            jptextcell = ws.cell(row = num+1, column=2)
            jptextcell.alignment = opx.styles.Alignment(wrap_text=True)
    
    ws.column_dimensions['B'].width = 100
    ws.column_dimensions['C'].width = 100
    wb.save(filetitle + '.xlsx')
    
    
    
def parsexlsx(xlfile):
    ws = xlfile.active
    data = []
    
    for row in ws.values:
        if (row[0] != "Dummy Text") and row[0]:
            if row[2]:
                
                data.append([row[0],row[2].replace("\n",repr("\n")[1:-1])]) #strip off surrounding '' with [1:-1]
            else:
                data.append([row[0],row[0]])
        
    return data
    


def createtxt(textpath, locpath, data):
    with open("./DSC/"+textpath[:-4]) as file:
        filedata = file.read()
    for i in data:
        #print(repr(i[1])[1:-1])
        filedata = filedata.replace(i[0]+"\"",i[1]+"\"") 
    with open(locpath+".\\"+textpath[:-4],"w") as newfile:
        newfile.write(filedata)
    
    
    
def main():
    if len(sys.argv) != 3:
        print("bad args. use python makexl.py x y, where x is either toxlsx or totxt, and y is the folder with files to read from")
    else:
        format = sys.argv[1]
        locpath = sys.argv[2]
        
        if format == "toxlsx":
            paths = os.listdir(locpath)
            for path in paths:
                path = locpath+".\\"+path
                if path.endswith(".txt"):
                    print(path)
                    with open(path, encoding="ansi") as file:
                        fdata = parsetxt(file)
                        #print(fdata)
                        createxlsx(path, fdata)
                
        elif format == "totxt":
            paths = os.listdir(locpath)
            for path in paths:
                if path.endswith(".xlsx"):
                    print(path)
                    wb = opx.load_workbook(locpath+".\\"+path)
                    wdata = parsexlsx(wb)                    
                    createtxt(path, locpath, wdata)
            
main()