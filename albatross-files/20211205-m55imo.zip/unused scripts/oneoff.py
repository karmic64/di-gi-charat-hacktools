import sys
import os
import openpyxl as opx

totalchars = 0

font = opx.styles.Font(name='Liberation Mono')

paths = os.listdir("newtodo")
for path in paths:
    if path.endswith(".xlsx"):
        print(path)
        new_wb = opx.load_workbook("./newtodo/"+path)
        #old_wb = opx.load_workbook("./realDSC/"+path)
        new_ws = new_wb.active
        #old_ws = old_wb.active
        
        #new_ws.move_range("A2:A999", cols=2)
        
        #colA = old_ws['A']
        #num = 0
        #for num,row in enumerate(range(1,len(colA)+1)): #LOL dont even ask bro
        #    _ = new_ws.cell(column=1, row=row, value=colA[row-1].value)
        #    num = num + 1
        
        #cellvals = new_ws['C']
        #for cellnum in range(1,len(cellvals)):
        #    if cellvals[cellnum].value:
        #        print(cellvals[cellnum].value)
        #        val = cellvals[cellnum].value
        #        if val[0:3] == "!!!":
        #            new_ws.cell(column=3,row=cellnum+1, value= "")
        
        #partsum = 0
        #colB = new_ws['B'][1:]
        #for cell in colB:
        #    if cell.value:
        #        text = cell.value.replace("#","")
                #print(text)
        #        partsum = partsum + len(text)
        #totalchars = totalchars + partsum
        #print(partsum)
        #print(totalchars)
            
        clen = len(new_ws['C'])
        for cellnum in range(1,clen+1):
            cellloc = "c"+str(cellnum)
            cell = new_ws[cellloc]
            cell.font = font
            if cell.value == "translation":
                cell.value = "this is sixteenw"
                print("detected")
        
        
        new_wb.save("./newtodo/"+path)