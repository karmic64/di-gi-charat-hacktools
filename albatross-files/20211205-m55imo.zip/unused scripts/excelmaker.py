import sys
import os
import openpyxl as opx


paths = os.listdir("realDSC")
for path in paths:
    if path.endswith(".txt"):
        with open("./realDSC/" + path) as file:
            lines = []
            for line in file:
                lines.append(line)
            for linenum, line in enumerate(lines):
                if (line.find("ShowSelMenu") != -1):
                    print("Found in " + path)
                    with open("./quarantine/" + path,"w+") as newfile:
                        newfile.write("".join(lines))

