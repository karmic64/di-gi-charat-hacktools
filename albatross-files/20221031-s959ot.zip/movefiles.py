import shutil
import sys
import os

names = ["3E1C90.txt",
"3E2550.txt",
"3E2980.txt",
"3E2D38.txt",
"3E331C.txt",
"3E35F8.txt",
"3E3970.txt",
"3E4818.txt",
"3E50B0.txt",
"3E56E0.txt",
"3E5B88.txt",
"3E61BC.txt",
"3E6914.txt",
"3E6F90.txt",
"3E775C.txt",
"3E84A4.txt",
"3E8D00.txt",
"3E9178.txt",
"3E98D8.txt",
"3EA274.txt",
"3EA7A8.txt",
"3EB1E8.txt",
"3EB67C.txt",
"3EBB94.txt",
"3EBFAC.txt",
"3EC49C.txt",
"3ECC2C.txt",
"3ED044.txt"]

for name in names:
    shutil.copy("./todo/"+name+".xlsx","./todo/temp/"+name+".xlsx")
    print("./todo/"+name+".xlsx", "./todo/temp/"+name+".xlsx")